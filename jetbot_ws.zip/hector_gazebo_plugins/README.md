# Hector Gazebo Plugins

This is the original package that you can download from the repository of Team Hector [here](https://github.com/tu-darmstadt-ros-pkg/hector_gazebo).

This package will help the simulation of any robot and in our case the jetbot differential drive robot AI Kit from Waveshare.

## Acknowledgement

Thanks to Technische Universität Darmstadt for developing these ROS incredible and useful packages.